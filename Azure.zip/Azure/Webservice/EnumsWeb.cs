﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Webservice
{
    public class EnumsWeb
    {

        public enum Userrole
        {
            Principal = 1,
            Teacher = 2,
            Substitute = 3,
            Parent = 4,
            Student = 5
        };

    }
}